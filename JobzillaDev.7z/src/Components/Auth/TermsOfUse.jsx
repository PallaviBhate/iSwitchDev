import React from 'react';
import Header from '../CommonComp/Header'
import Footer from '../CommonComp/Footer'
const TermsofUse =()=>{
    return(
        <div className="content">
        <Header></Header>
        <div className="main">
            <h3>Welcome to TermsofUse Page</h3>
        </div>
        <Footer></Footer>
        </div>
    )
}

export default TermsofUse