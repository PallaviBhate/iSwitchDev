import React, { Component } from 'react'
import Interviews from '../../CommonComp/Interviews';

class Accepted extends Component {
  render() {
    return (
      <Interviews />
    );
  }
}

export default Accepted