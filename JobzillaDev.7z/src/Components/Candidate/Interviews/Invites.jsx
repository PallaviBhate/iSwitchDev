import React, { Component } from 'react'
import Interviews from '../../CommonComp/Interviews';

class Invites extends Component {
  render() {
    return (
      <Interviews isInvites={true} />
    );
  }
}

export default Invites