export * from './about';
export * from './education';
export * from './employment';
export * from './information';
export * from './personalDetails';
export * from './resume';
export * from './skills';
export * from './navBar';