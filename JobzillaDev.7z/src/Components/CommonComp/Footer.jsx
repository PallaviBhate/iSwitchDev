import React from 'react'

const Footer =()=>{
    return(
    <footer>
    <div className="login_Signup_footer align-self-center text-center py-3">Copyright &copy; 2020 | Jobzilla Pvt. Ltd.</div>
    </footer>)
}
export default Footer 