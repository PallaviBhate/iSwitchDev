import React from 'react';

export const Breadcrumbs = () => {
  return (
    <div>
      <h4>Profile</h4>
    </div>
  );
}