
//Common Header to use in API call
export const ApiHeader = {headers: { 'Content-Type': 'application/json',}};
// Base URL to use
export const ApiBaseUrl = "https://techm-jobzilla.herokuapp.com/jobs";
