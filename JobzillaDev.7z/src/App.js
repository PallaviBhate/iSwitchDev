import React from 'react';
import './Assets/css/Style.css'
import RouterSettings from './Routing/RouterSettings';

function App() {
  return (
    <div className="App">
     <RouterSettings></RouterSettings>
   
    </div>
  );
}

export default App;
